package projectfx;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ProjectFX extends Application {

    private BorderPane mainLayout;
    private Button navHome, navRent, navMe;
    private StackPane contentArea;

    @Override
    public void start(Stage primaryStage) {
        mainLayout = new BorderPane();
        mainLayout.getStyleClass().add("root");

        HBox topBar = createTopBar();
        mainLayout.setTop(topBar);

        contentArea = new StackPane();
        mainLayout.setCenter(contentArea);

        HBox bottomNav = createBottomNav();
        mainLayout.setBottom(bottomNav);

        showHomePage();

        Scene scene = new Scene(mainLayout, 900, 680);
        scene.getStylesheets().add(getClass().getResource("/projectfx/css/style.css").toExternalForm());
        primaryStage.setTitle("RentalC - Car Rental");
        primaryStage.setMinWidth(800);
        primaryStage.setMinHeight(600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private HBox createTopBar() {
        HBox topBar = new HBox(16);
        topBar.getStyleClass().add("top-bar");
        topBar.setAlignment(Pos.CENTER_LEFT);

        Label logo = new Label("\u26A1 RentalC");
        logo.getStyleClass().add("logo-text");

        Region spacer1 = new Region();
        HBox.setHgrow(spacer1, Priority.ALWAYS);

        TextField searchField = new TextField();
        searchField.setPromptText("\uD83D\uDD0D  Search cars, brands...");
        searchField.getStyleClass().add("search-field");

        Region spacer2 = new Region();
        HBox.setHgrow(spacer2, Priority.ALWAYS);

        Button bellBtn = new Button("\uD83D\uDD14");
        bellBtn.getStyleClass().add("icon-button");

        Button settingsBtn = new Button("\u2699");
        settingsBtn.getStyleClass().add("icon-button");

        topBar.getChildren().addAll(logo, spacer1, searchField, spacer2, bellBtn, settingsBtn);
        return topBar;
    }

    private HBox createBottomNav() {
        HBox bottomNav = new HBox();
        bottomNav.getStyleClass().add("bottom-nav");
        bottomNav.setAlignment(Pos.CENTER);

        navHome = createNavButton("\uD83C\uDFE0", "Home", true);
        navRent = createNavButton("\uD83D\uDE97", "Rent", false);
        navMe = createNavButton("\uD83D\uDC64", "Me", false);

        navHome.setOnAction(e -> { setActiveNav(navHome); showHomePage(); });
        navRent.setOnAction(e -> { setActiveNav(navRent); showRentPage(); });
        navMe.setOnAction(e -> { setActiveNav(navMe); showProfilePage(); });

        Region s1 = new Region();
        HBox.setHgrow(s1, Priority.ALWAYS);
        Region s2 = new Region();
        HBox.setHgrow(s2, Priority.ALWAYS);
        Region s3 = new Region();
        HBox.setHgrow(s3, Priority.ALWAYS);
        Region s4 = new Region();
        HBox.setHgrow(s4, Priority.ALWAYS);

        bottomNav.getChildren().addAll(s1, navHome, s2, navRent, s3, navMe, s4);
        return bottomNav;
    }

    private Button createNavButton(String icon, String text, boolean active) {
        Button btn = new Button(icon + "\n" + text);
        btn.getStyleClass().add(active ? "nav-button-active" : "nav-button");
        btn.setWrapText(true);
        return btn;
    }

    private void setActiveNav(Button activeBtn) {
        navHome.getStyleClass().setAll(navHome == activeBtn ? "nav-button-active" : "nav-button");
        navRent.getStyleClass().setAll(navRent == activeBtn ? "nav-button-active" : "nav-button");
        navMe.getStyleClass().setAll(navMe == activeBtn ? "nav-button-active" : "nav-button");
    }

    private void showHomePage() {
        contentArea.getChildren().clear();
        ScrollPane scroll = new ScrollPane();
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.getStyleClass().add("scroll-pane");

        VBox page = new VBox(0);
        page.setStyle("-fx-background-color: #f5f7fa;");

        VBox hero = createHeroSection();

        HBox statsRow = createStatsRow();

        VBox picksSection = createPicksSection();

        VBox featuresSection = createFeaturesSection();

        page.getChildren().addAll(hero, statsRow, picksSection, featuresSection);
        scroll.setContent(page);
        contentArea.getChildren().add(scroll);
    }

    private VBox createHeroSection() {
        VBox hero = new VBox(12);
        hero.getStyleClass().add("hero-section");

        Label welcome = new Label("Welcome to RentalC");
        welcome.getStyleClass().add("hero-title");

        Label sub = new Label("Find and rent your dream car today.\nBest prices, premium selection.");
        sub.getStyleClass().add("hero-subtitle");
        sub.setWrapText(true);

        Button browseBtn = new Button("Browse Cars \u2192");
        browseBtn.getStyleClass().add("hero-button");
        browseBtn.setOnAction(e -> { setActiveNav(navRent); showRentPage(); });

        VBox.setMargin(browseBtn, new Insets(8, 0, 0, 0));
        hero.getChildren().addAll(welcome, sub, browseBtn);
        return hero;
    }

    private HBox createStatsRow() {
        HBox stats = new HBox(16);
        stats.setPadding(new Insets(24, 24, 8, 24));
        stats.setAlignment(Pos.CENTER);

        stats.getChildren().addAll(
            createStatCard("150+", "Cars Available"),
            createStatCard("4.8\u2605", "Average Rating"),
            createStatCard("10K+", "Happy Customers"),
            createStatCard("24/7", "Support")
        );
        return stats;
    }

    private VBox createStatCard(String number, String label) {
        VBox card = new VBox(4);
        card.getStyleClass().add("stats-card");
        card.setAlignment(Pos.CENTER);
        card.setPrefWidth(180);

        Label numLabel = new Label(number);
        numLabel.getStyleClass().add("stats-number");

        Label textLabel = new Label(label);
        textLabel.getStyleClass().add("stats-label");

        card.getChildren().addAll(numLabel, textLabel);
        HBox.setHgrow(card, Priority.ALWAYS);
        return card;
    }

    private VBox createPicksSection() {
        VBox section = new VBox(16);
        section.setPadding(new Insets(24));

        Label title = new Label("Picks for You");
        title.getStyleClass().add("section-title");

        HBox cards = new HBox(16);
        cards.setAlignment(Pos.CENTER_LEFT);

        String[] names = {"Tesla Model 3", "BMW X5", "Mercedes C-Class", "Audi A6"};
        String[] categories = {"Electric", "SUV", "Sedan", "Sedan"};
        String[] prices = {"$89", "$120", "$95", "$110"};
        String[] ratings = {"4.9", "4.7", "4.8", "4.6"};
        String[] images = {"car1.jpg", "car2.jpg", "car3.jpg", "car4.jpg"};

        for (int i = 0; i < 4; i++) {
            VBox card = createCarCard(names[i], categories[i], prices[i], ratings[i], images[i]);
            HBox.setHgrow(card, Priority.ALWAYS);
            cards.getChildren().add(card);
        }

        section.getChildren().addAll(title, cards);
        return section;
    }

    private VBox createCarCard(String name, String category, String price, String rating, String imgFile) {
        VBox card = new VBox(0);
        card.getStyleClass().add("car-card");
        card.setMaxWidth(210);
        card.setMinWidth(180);

        StackPane imageContainer = new StackPane();
        imageContainer.setMinHeight(120);
        imageContainer.setStyle("-fx-background-color: #f8f9fa; -fx-background-radius: 16 16 0 0;");

        try {
            Image img = new Image(getClass().getResourceAsStream("/projectfx/images/" + imgFile));
            ImageView iv = new ImageView(img);
            iv.setFitWidth(180);
            iv.setFitHeight(110);
            iv.setPreserveRatio(true);
            iv.setSmooth(true);
            Rectangle clip = new Rectangle(180, 110);
            clip.setArcWidth(16);
            clip.setArcHeight(16);
            iv.setClip(clip);
            imageContainer.getChildren().add(iv);
        } catch (Exception e) {
            Label placeholder = new Label("\uD83D\uDE97");
            placeholder.setStyle("-fx-font-size: 48px; -fx-text-fill: #ddd;");
            imageContainer.getChildren().add(placeholder);
        }

        VBox info = new VBox(4);
        info.setPadding(new Insets(12));

        Label catLabel = new Label(category.toUpperCase());
        catLabel.getStyleClass().add("car-card-category");

        Label nameLabel = new Label(name);
        nameLabel.getStyleClass().add("car-card-name");

        HBox ratingBox = new HBox(4);
        ratingBox.setAlignment(Pos.CENTER_LEFT);
        Label starLabel = new Label("\u2605 " + rating);
        starLabel.getStyleClass().add("rating-star");
        ratingBox.getChildren().add(starLabel);

        HBox priceRow = new HBox(4);
        priceRow.setAlignment(Pos.CENTER_LEFT);
        Label priceLabel = new Label(price);
        priceLabel.getStyleClass().add("car-card-price");
        Label perDay = new Label("/day");
        perDay.getStyleClass().add("car-card-period");
        priceRow.getChildren().addAll(priceLabel, perDay);

        Button rentBtn = new Button("Rent Now");
        rentBtn.getStyleClass().add("rent-button");
        rentBtn.setMaxWidth(Double.MAX_VALUE);
        VBox.setMargin(rentBtn, new Insets(8, 0, 0, 0));

        info.getChildren().addAll(catLabel, nameLabel, ratingBox, priceRow, rentBtn);
        card.getChildren().addAll(imageContainer, info);
        return card;
    }

    private VBox createFeaturesSection() {
        VBox section = new VBox(16);
        section.setPadding(new Insets(8, 24, 24, 24));

        Label title = new Label("Why Choose RentalC?");
        title.getStyleClass().add("section-title");

        HBox features = new HBox(16);
        features.setAlignment(Pos.CENTER);

        features.getChildren().addAll(
            createFeatureItem("\uD83D\uDEE1\uFE0F", "Fully Insured", "All vehicles come with\ncomprehensive insurance"),
            createFeatureItem("\uD83D\uDCB0", "Best Prices", "Competitive rates with\nno hidden fees"),
            createFeatureItem("\u23F0", "24/7 Service", "Round the clock\ncustomer support"),
            createFeatureItem("\uD83D\uDE80", "Fast Booking", "Book your car in\nunder 2 minutes")
        );

        section.getChildren().addAll(title, features);
        return section;
    }

    private VBox createFeatureItem(String icon, String title, String description) {
        VBox item = new VBox(8);
        item.setAlignment(Pos.CENTER);
        item.setPadding(new Insets(16));
        item.getStyleClass().add("stats-card");

        StackPane iconBox = new StackPane();
        iconBox.getStyleClass().add("feature-icon-box");
        Label iconLabel = new Label(icon);
        iconLabel.getStyleClass().add("feature-icon");
        iconBox.getChildren().add(iconLabel);

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #2d3436;");

        Label descLabel = new Label(description);
        descLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #999; -fx-text-alignment: center;");
        descLabel.setWrapText(true);

        item.getChildren().addAll(iconBox, titleLabel, descLabel);
        HBox.setHgrow(item, Priority.ALWAYS);
        return item;
    }

    private void showRentPage() {
        contentArea.getChildren().clear();
        ScrollPane scroll = new ScrollPane();
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.getStyleClass().add("scroll-pane");

        VBox page = new VBox(20);
        page.setPadding(new Insets(24));
        page.setStyle("-fx-background-color: #f5f7fa;");

        Label title = new Label("Browse Cars");
        title.getStyleClass().add("section-title");

        HBox categories = new HBox(10);
        categories.setAlignment(Pos.CENTER_LEFT);
        String[] cats = {"All", "Sedan", "SUV", "Electric", "Sports", "Luxury"};
        for (int i = 0; i < cats.length; i++) {
            Button chip = new Button(cats[i]);
            chip.getStyleClass().add(i == 0 ? "category-chip-active" : "category-chip");
            categories.getChildren().add(chip);
        }

        HBox filterBar = new HBox(12);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        ComboBox<String> sortBox = new ComboBox<>();
        sortBox.getItems().addAll("Price: Low to High", "Price: High to Low", "Rating", "Newest");
        sortBox.setValue("Price: Low to High");
        sortBox.setStyle("-fx-background-radius: 20; -fx-border-radius: 20;");
        Label resultsLabel = new Label("12 cars available");
        resultsLabel.setStyle("-fx-text-fill: #999; -fx-font-size: 13px;");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        filterBar.getChildren().addAll(resultsLabel, spacer, sortBox);

        GridPane grid = new GridPane();
        grid.setHgap(16);
        grid.setVgap(16);

        String[] names = {"Tesla Model 3", "BMW X5", "Mercedes C-Class", "Audi A6",
                          "Porsche 911", "Range Rover", "Toyota Camry", "Honda Civic",
                          "Ford Mustang", "Chevrolet Corvette", "Lexus ES", "Volvo XC90"};
        String[] catLabels = {"Electric", "SUV", "Sedan", "Sedan",
                              "Sports", "SUV", "Sedan", "Sedan",
                              "Sports", "Sports", "Luxury", "SUV"};
        String[] prices = {"$89", "$120", "$95", "$110",
                           "$180", "$150", "$65", "$55",
                           "$140", "$200", "$100", "$130"};
        String[] ratings = {"4.9", "4.7", "4.8", "4.6",
                            "4.9", "4.5", "4.4", "4.3",
                            "4.8", "4.9", "4.6", "4.7"};
        String[] imgs = {"car1.jpg", "car2.jpg", "car3.jpg", "car4.jpg",
                         "car1.jpg", "car2.jpg", "car3.jpg", "car4.jpg",
                         "car1.jpg", "car2.jpg", "car3.jpg", "car4.jpg"};

        for (int i = 0; i < 12; i++) {
            VBox card = createCarCard(names[i], catLabels[i], prices[i], ratings[i], imgs[i]);
            grid.add(card, i % 4, i / 4);
        }

        ColumnConstraints cc = new ColumnConstraints();
        cc.setPercentWidth(25);
        cc.setHgrow(Priority.ALWAYS);
        for (int i = 0; i < 4; i++) {
            grid.getColumnConstraints().add(cc);
        }

        page.getChildren().addAll(title, categories, filterBar, grid);
        scroll.setContent(page);
        contentArea.getChildren().add(scroll);
    }

    private void showProfilePage() {
        contentArea.getChildren().clear();
        ScrollPane scroll = new ScrollPane();
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.getStyleClass().add("scroll-pane");

        VBox page = new VBox(20);
        page.setPadding(new Insets(24));
        page.setStyle("-fx-background-color: #f5f7fa;");

        VBox profileCard = new VBox(16);
        profileCard.getStyleClass().add("profile-section");
        profileCard.setAlignment(Pos.CENTER);

        StackPane avatar = new StackPane();
        avatar.getStyleClass().add("profile-avatar");
        Label avatarText = new Label("U");
        avatarText.getStyleClass().add("profile-avatar-text");
        avatar.getChildren().add(avatarText);

        Label nameLabel = new Label("User Name");
        nameLabel.getStyleClass().add("profile-name");

        Label emailLabel = new Label("user@rentalc.com");
        emailLabel.getStyleClass().add("profile-email");

        Label memberSince = new Label("Member since 2024");
        memberSince.setStyle("-fx-text-fill: #999; -fx-font-size: 12px;");

        HBox badgeBox = new HBox(8);
        badgeBox.setAlignment(Pos.CENTER);
        Label badge = new Label("PREMIUM");
        badge.getStyleClass().add("badge");
        badgeBox.getChildren().add(badge);

        profileCard.getChildren().addAll(avatar, nameLabel, emailLabel, memberSince, badgeBox);

        HBox profileStats = new HBox(16);
        profileStats.setAlignment(Pos.CENTER);
        profileStats.getChildren().addAll(
            createStatCard("12", "Total Trips"),
            createStatCard("$1,250", "Total Spent"),
            createStatCard("450", "Points Earned")
        );

        VBox menuSection = new VBox(0);
        menuSection.getStyleClass().add("profile-section");
        menuSection.setPadding(new Insets(0));

        Label menuTitle = new Label("Account");
        menuTitle.getStyleClass().add("section-title");
        VBox.setMargin(menuTitle, new Insets(16, 16, 8, 16));

        menuSection.getChildren().add(menuTitle);
        menuSection.getChildren().addAll(
            createMenuItem("\uD83D\uDC64", "Edit Profile", "Update your personal info"),
            createMenuItem("\uD83D\uDCB3", "Payment Methods", "Manage cards and wallets"),
            createMenuItem("\uD83D\uDCC4", "Booking History", "View past and upcoming trips"),
            createMenuItem("\u2764\uFE0F", "Favorites", "Your saved cars"),
            createMenuItem("\uD83D\uDD14", "Notifications", "Manage alert preferences"),
            createMenuItem("\uD83C\uDF81", "Rewards", "Check your loyalty points"),
            createMenuItem("\u2699\uFE0F", "Settings", "App preferences"),
            createMenuItem("\u2753", "Help & Support", "FAQs and contact us")
        );

        VBox logoutSection = new VBox();
        logoutSection.setAlignment(Pos.CENTER);
        logoutSection.setPadding(new Insets(8));
        Button logoutBtn = new Button("Log Out");
        logoutBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #e74c3c; -fx-font-size: 15px; -fx-font-weight: bold; -fx-cursor: hand; -fx-border-color: #e74c3c; -fx-border-radius: 25; -fx-background-radius: 25; -fx-padding: 10 40;");
        logoutSection.getChildren().add(logoutBtn);

        page.getChildren().addAll(profileCard, profileStats, menuSection, logoutSection);
        scroll.setContent(page);
        contentArea.getChildren().add(scroll);
    }

    private HBox createMenuItem(String icon, String title, String subtitle) {
        HBox item = new HBox(16);
        item.getStyleClass().add("menu-item");
        item.setAlignment(Pos.CENTER_LEFT);

        Label iconLabel = new Label(icon);
        iconLabel.getStyleClass().add("menu-item-icon");

        VBox textBox = new VBox(2);
        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("menu-item-text");
        Label subLabel = new Label(subtitle);
        subLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #999;");
        textBox.getChildren().addAll(titleLabel, subLabel);
        HBox.setHgrow(textBox, Priority.ALWAYS);

        Label arrow = new Label("\u203A");
        arrow.setStyle("-fx-font-size: 20px; -fx-text-fill: #ccc;");

        item.getChildren().addAll(iconLabel, textBox, arrow);
        return item;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
