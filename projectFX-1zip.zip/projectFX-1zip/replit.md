# replit.md

## Overview

This is a JavaFX desktop application project. Based on the available files, it appears to be in early stages of development, featuring a UI with a social-media or content-platform inspired design (top bar with logo, search field, and icon buttons). The project uses Maven-style directory conventions (`src/main/resources/` and `target/classes/`) and has an orange-themed brand color (`#ea5f02`).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework**: JavaFX — a Java-based desktop GUI framework
- **Styling**: CSS stylesheets located at `src/main/resources/projectfx/css/style.css`
- **Design Language**: Modern, clean UI with rounded elements, subtle shadows, and a white/light-gray color scheme with orange (`#ea5f02`) as the primary accent color
- **Package Structure**: The project uses `projectfx` as its base package name

### Build System
- **Convention**: Follows Maven standard directory layout (`src/main/resources/` for source, `target/classes/` for compiled output)
- **Build Tool**: Likely Maven or Gradle (no build config file is present in the provided files, but the directory structure strongly suggests Maven)

### Current State
- The project currently only contains CSS styling files. Java source files, FXML layouts, and build configuration files (like `pom.xml` or `build.gradle`) are not yet present or not provided.
- When adding Java source code, it should go under `src/main/java/projectfx/`
- FXML files (if used) should go under `src/main/resources/projectfx/`

### Key Design Decisions
1. **JavaFX for UI**: Chosen for building a cross-platform desktop application with rich UI capabilities. JavaFX supports CSS styling, making it easy to create modern-looking interfaces.
2. **CSS-based styling**: UI appearance is separated from logic via external CSS files rather than inline styles, following good separation of concerns.
3. **Maven directory layout**: Standard Java project structure for maintainability and compatibility with common build tools.

## External Dependencies

- **JavaFX SDK**: Required runtime dependency for the GUI framework. When setting up the project, ensure JavaFX libraries are included (typically via Maven dependency `org.openjfx`).
- **Java JDK**: Requires JDK 11+ (JavaFX was decoupled from the JDK starting with Java 11, so it needs to be added as a separate dependency).
- No database, API, or third-party service integrations are evident from the current codebase. These may be added as the project develops.